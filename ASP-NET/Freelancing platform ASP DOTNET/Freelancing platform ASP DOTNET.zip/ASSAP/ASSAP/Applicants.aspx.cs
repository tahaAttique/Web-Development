﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASSAP
{
    public partial class Applicants : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM NewFreelancersApplication";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterPosts.DataSource = ds;
                RepeaterPosts.DataBind();

            }
        }

        protected void RepeaterPosts_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {


            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {

                var btn = e.Item.FindControl("btnDelete") as Button;

                if (btn != null)
                {
                    btn.Click += new EventHandler(btnDelete_Click);
                }
   

            }

        }

        protected void btnDelete_Click(object sender, EventArgs e) //ApproveRequest
        {
            var argument = ((Button)sender).CommandArgument;

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
                string query = "DELETE FROM NewFreelancersApplication WHERE (Id=@var1)";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@var1", argument.Trim());
                sqlCmd.ExecuteNonQuery();
                Page.Response.Redirect(Page.Request.Url.ToString(), true);
            }

            Response.Redirect(Request.RawUrl);
        }

    }
}