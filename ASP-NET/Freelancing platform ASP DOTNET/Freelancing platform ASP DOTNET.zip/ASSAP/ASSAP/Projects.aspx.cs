﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASSAP
{
    public partial class Projects : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM ApprovedProject WHERE AdminComments='NotAssigned'";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterNotAssigned.DataSource = ds;
                RepeaterNotAssigned.DataBind();

            }

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM ApprovedProject WHERE AdminComments='Assigned'";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterAssigned.DataSource = ds;
                RepeaterAssigned.DataBind();

            }

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM ApprovedProject WHERE AdminComments='Delayed'";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterDelayed.DataSource = ds;
                RepeaterDelayed.DataBind();

            }


            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM ApprovedProject WHERE AdminComments='Completed'";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterCompleted.DataSource = ds;
                RepeaterCompleted.DataBind();

            }

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM ApprovedProject";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterAll.DataSource = ds;
                RepeaterAll.DataBind();

            }

            
        }
    }
}