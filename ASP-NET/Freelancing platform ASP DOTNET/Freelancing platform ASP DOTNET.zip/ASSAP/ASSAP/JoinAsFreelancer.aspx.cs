﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASSAP
{
    public partial class JoinAsFreelancer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        string photo_path = null;
        protected void btn_Submit_Click(object sender, EventArgs e)
        {
            if (Portfolio_Upload.HasFile)
            {
                string extension = System.IO.Path.GetExtension(Portfolio_Upload.FileName);
                //lbPhotoUpload.Text = extension;


              //  if (extension == ".jpg" || extension == ".png" || extension == ".gif")
                {
                    string path = Server.MapPath("\\");


                    Portfolio_Upload.SaveAs(path + Portfolio_Upload.FileName);
                    photo_path = Portfolio_Upload.FileName;

                    ViewState["photoPath"] = Portfolio_Upload.FileName;
                }
             //   else
                {

                }
              
            }
            else
            {
              //  lbPhotoUpload.Text = "Plz select a file";
            }


                

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                if (ViewState["photoPath"] != null)
                {
                    photo_path = (string)ViewState["photoPath"];
                }
                sqlCon.Open();
                string query = "INSERT INTO NewFreelancersApplication VALUES(@FullName,@Email,@Mobile,@Profession,@Portfolio)";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@FullName", txtFullname.Text.Trim());    
                sqlCmd.Parameters.AddWithValue("@Email", txtEmail.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Mobile", txtMobile.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Profession", txtProfession.Text.Trim());

                if (photo_path != null)
                {
                    sqlCmd.Parameters.AddWithValue("@Portfolio", photo_path.Trim());
                }
                else
                {
                    photo_path = "";
                    sqlCmd.Parameters.AddWithValue("@Portfolio", photo_path.Trim());
                }

                sqlCmd.ExecuteNonQuery();

                //Page.Response.Redirect(Page.Request.Url.ToString(), true);


            }
            
        }
    }
}