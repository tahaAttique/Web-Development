﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASSAP
{
    public partial class Freelancer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM Freelancer";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterAllFreelancers.DataSource = ds;
                RepeaterAllFreelancers.DataBind();

            }


        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
                string query = "INSERT INTO Freelancer VALUES(@name,@em,@user,@pwd,@phone,@add)";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@name", fullname.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@em", email.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@user", username.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@pwd", password.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@phone", phone.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@add", address.Text.Trim());
                sqlCmd.ExecuteNonQuery();

            }
        }

    }
}