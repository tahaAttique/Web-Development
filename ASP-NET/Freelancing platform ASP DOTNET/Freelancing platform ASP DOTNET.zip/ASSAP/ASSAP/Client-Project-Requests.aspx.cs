﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASSAP
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASSAP_DB;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM ClientPSubmission WHERE AdminComments='Request'";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterPosts.DataSource = ds;
                RepeaterPosts.DataBind();

            }

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASSAP_DB;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM ClientPSubmission WHERE AdminComments='Approved'";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterPostsApprove.DataSource = ds;
                RepeaterPostsApprove.DataBind();

            }
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASSAP_DB;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM ClientPSubmission WHERE AdminComments='Cancelled'";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterCancelled.DataSource = ds;
                RepeaterCancelled.DataBind();

            }
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASSAP_DB;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM ClientPSubmission WHERE AdminComments='Finished'";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterFinished.DataSource = ds;
                RepeaterFinished.DataBind();

            }
    
            




        }

        protected void RepeaterPosts_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {


            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {

                var btn = e.Item.FindControl("ApproveRequest") as Button;
                var btnDiscard = e.Item.FindControl("DiscardRequest") as Button;
                var btnFinished = e.Item.FindControl("FinishRequest") as Button;

                if (btn != null)
                {
                    btn.Click += new EventHandler(ApproveRequest_Click);
                }
                if (btnDiscard != null)
                {
                    btnDiscard.Click += new EventHandler(DiscardRequest_Click);
                }
                if (btnFinished != null)
                {
                    btnFinished.Click += new EventHandler(btnFinished_Click);
                }


            }

        }

        protected void ApproveRequest_Click(object sender, EventArgs e) //ApproveRequest
        {
            var argument = ((Button)sender).CommandArgument;

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASSAP_DB;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "UPDATE ClientPSubmission SET AdminComments = 'Approved' WHERE Id = @var1 ; ";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@var1", argument);
                sqlCmd.ExecuteNonQuery();

            }

            Response.Redirect(Request.RawUrl);
        }

        protected void DiscardRequest_Click(object sender, EventArgs e) // CancelRequest_Click
        {
            var argument = ((Button)sender).CommandArgument;
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASSAP_DB;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "UPDATE ClientPSubmission SET AdminComments = 'Cancelled' WHERE Id = @var1 ; ";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@var1", argument);
                sqlCmd.ExecuteNonQuery();

            }

            Response.Redirect(Request.RawUrl);
        }

        protected void btnFinished_Click(object sender, EventArgs e) // CancelRequest_Click
        {
            var argument = ((Button)sender).CommandArgument;
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASSAP_DB;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "UPDATE ClientPSubmission SET AdminComments = 'Finished' WHERE Id = @var1 ; ";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@var1", argument);
                sqlCmd.ExecuteNonQuery();

            }

            Response.Redirect(Request.RawUrl);
        }

        protected void btSubmit_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
                string query = "INSERT INTO ApprovedProject VALUES(@Pname,@Ptype,@Duration,@PDetail,'','NotAssigned')";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@Pname", PName.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Ptype", ProjectType.SelectedItem.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Duration", Duration.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@PDetail", PDetails.Text.Trim());
                sqlCmd.ExecuteNonQuery();
            }
        }
    }

}