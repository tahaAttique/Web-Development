﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASSAP
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btSubmit_Click(object sender, EventArgs e)
        {

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASSAP_DB;Integrated Security=True;Pooling=False"))
            {
              
                sqlCon.Open();
                string query = "INSERT INTO ClientPSubmission VALUES(@FirstName,@LastName,@Email,@Mobile,@DOB,@Pname,@Ptype,@PDetail,@Duration,'Request')";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@FirstName", FName.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@LastName", LName.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Email", Email.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Mobile", Tel.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@DOB", DOB.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Pname", PName.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Ptype", ProjectType.SelectedItem.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@Duration", Duration.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@PDetail", PDetails.Text.Trim());


                sqlCmd.ExecuteNonQuery();

                //Page.Response.Redirect(Page.Request.Url.ToString(), true);


            }
        }
    }
}