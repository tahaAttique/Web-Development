﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASSAP
{
    public partial class SelectProject : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (Session["Username"] == null)
            {
                Response.Redirect("Freelancer-login.aspx");
            }
            if (!IsPostBack)
            {
                using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
                {
                    sqlCon.Open();
                    string query = "SELECT * FROM ApprovedProject WHERE AdminComments='Assigned'";
                    SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                    //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                    sqlCmd.ExecuteNonQuery();

                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = sqlCmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds, "ProjectName");
                    Projects.DataSource = ds;
                    Projects.DataBind();

                }
                using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
                {
                    sqlCon.Open();
                    string query1 = "SELECT * FROM ApprovedProject WHERE AdminComments='NotAssigned'";
                    SqlCommand sqlCmd = new SqlCommand(query1, sqlCon);
                    //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                    sqlCmd.ExecuteNonQuery();

                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = sqlCmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds, "ProjectName");
                    Repeater1.DataSource = ds;
                    Repeater1.DataBind();

                }
                using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
                {
                    sqlCon.Open();
                    string query2 = "SELECT * FROM ApprovedProject WHERE AdminComments='Delayed'";
                    SqlCommand sqlCmd = new SqlCommand(query2, sqlCon);
                    //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                    sqlCmd.ExecuteNonQuery();

                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = sqlCmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds, "ProjectName");
                    DelayedRepeater.DataSource = ds;
                    DelayedRepeater.DataBind();

                }
                using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
                {
                    sqlCon.Open();
                    string query3 = "SELECT * FROM ApprovedProject WHERE AdminComments='Completed'";
                    SqlCommand sqlCmd = new SqlCommand(query3, sqlCon);
                    //sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                    sqlCmd.ExecuteNonQuery();

                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = sqlCmd;
                    DataSet ds = new DataSet();
                    da.Fill(ds, "ProjectName");
                    CompletedProject.DataSource = ds;
                    CompletedProject.DataBind();

                }
                

            }

        }

        protected void RepeaterProjects_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var btn = e.Item.FindControl("lnkEdit") as Button;
                var btnLike = e.Item.FindControl("lnkUpdate") as Button;
                if (btn != null)
                {
                    btn.Click += new EventHandler(OnEdit);
                }
                if (btnLike != null)
                {
                    btnLike.Click += new EventHandler(OnUpdate);
                }
            }
        }
        protected void OnEdit(object sender, EventArgs e)
        {

            RepeaterItem item = (sender as Button).Parent as RepeaterItem;
            this.ToggleElements(item, true);
        }
        private void ToggleElements(RepeaterItem item, bool isEdit)
        {

            item.FindControl("lnkEdit").Visible = !isEdit;
            item.FindControl("lnkUpdate").Visible = isEdit;

            item.FindControl("Ftext").Visible = isEdit;

        }
        protected void OnUpdate(object sender, EventArgs e)
        {

            RepeaterItem item = (sender as Button).Parent as RepeaterItem;
            var argument = ((Button)sender).CommandArgument;
            string fr = (item.FindControl("Ftext") as TextBox).Text.Trim();

            //string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
               string query = "UPDATE ApprovedProject SET Freelancer= @freelancer WHERE Id = @var1; ";

                SqlCommand cmd = new SqlCommand(query, sqlCon);


                cmd.Parameters.AddWithValue("@freelancer", fr);
                cmd.Parameters.AddWithValue("@var1", argument);
                cmd.ExecuteNonQuery();


                if(fr !="")
                {
                    string query1 = "UPDATE ApprovedProject SET AdminComments= @AC WHERE Id = @var1; ";
                    SqlCommand cmd1 = new SqlCommand(query1, sqlCon);

                    cmd1.Parameters.AddWithValue("@AC", "Assigned");
                    cmd1.Parameters.AddWithValue("@var1", argument);
                    cmd1.ExecuteNonQuery();

                }


                sqlCon.Close();
            }
            Response.Redirect(Request.RawUrl);
        }

        protected void Delayed(object sender, EventArgs e)
        {

            RepeaterItem item = (sender as Button).Parent as RepeaterItem;
            var argument = ((Button)sender).CommandArgument;
            string fr = (item.FindControl("Ftext") as TextBox).Text.Trim();

            //string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();
              
                
                    string query1 = "UPDATE ApprovedProject SET AdminComments= @AC WHERE Id = @var1; ";
                    SqlCommand cmd1 = new SqlCommand(query1, sqlCon);

                    cmd1.Parameters.AddWithValue("@AC", "Delayed");
                    cmd1.Parameters.AddWithValue("@var1", argument);
                    cmd1.ExecuteNonQuery();

                sqlCon.Close();
            }
            Response.Redirect(Request.RawUrl);
        }
        
       protected void Completed(object sender, EventArgs e)
        {

            RepeaterItem item = (sender as Button).Parent as RepeaterItem;
            var argument = ((Button)sender).CommandArgument;
            string fr = (item.FindControl("Ftext") as TextBox).Text.Trim();

            //string constr = ConfigurationManager.ConnectionStrings["constr"].ConnectionString;
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=ASAAP;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False"))
            {
                sqlCon.Open();


                string query1 = "UPDATE ApprovedProject SET AdminComments= @AC WHERE Id = @var1; ";
                SqlCommand cmd1 = new SqlCommand(query1, sqlCon);

                cmd1.Parameters.AddWithValue("@AC", "Completed");
                cmd1.Parameters.AddWithValue("@var1", argument);
                cmd1.ExecuteNonQuery();

                sqlCon.Close();
            }
            Response.Redirect(Request.RawUrl);
        }

    }

}