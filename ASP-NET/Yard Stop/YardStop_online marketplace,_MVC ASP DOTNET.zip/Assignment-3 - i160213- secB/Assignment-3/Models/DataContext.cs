﻿using Assignment_3.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace Assignment_3
{
    public class DataContext: DbContext
    {
       public DbSet<User> Users { get; set; }
         
    }
}