﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace Assignment_3.Models
{
    public class User
    {   
        [Key]
        public int userId { get; set; }

        [Required]
        [Display(Name ="Username")]
        public string username { get; set; }

        [Required]
        [Display(Name ="Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        
        [Display(Name ="Full Name")]
        public string Fullname { get; set; }

      
        [Display(Name = "Email")]
        [DataType(DataType.EmailAddress , ErrorMessage = "Email is not valid")]
        public string  email { get; set; }

       
        [Display(Name = "Mobile Num")]
        public string  mobile { get; set; }

        [Display(Name ="Upload Image")]
        public string ImagePath { get; set; }

        [NotMapped]
        public HttpPostedFileBase ImageFile { get; set; }


    }
}