﻿using Assignment_3.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Assignment_3.Controllers
{
    public class UsersController : Controller
    {
        private DataContext db = new DataContext();
        // GET: Users
        public ActionResult Index()
        {
            return View(db.Users.ToList());
        }

        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(User usr)
        {
            if(ModelState.IsValid)
            {
                string filename = Path.GetFileNameWithoutExtension(usr.ImageFile.FileName);
                string extension = Path.GetExtension(usr.ImageFile.FileName);
                filename = filename + DateTime.Now.ToString("yymmssfff") + extension;
                usr.ImagePath = "~/Images/" + filename;
                filename = Path.Combine(Server.MapPath(usr.ImagePath));
                usr.ImageFile.SaveAs(filename);

                db.Users.Add(usr);
                db.SaveChanges();
                ModelState.Clear();
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError("", " Some Error Occured");
            }

            return View(usr);
        }

        public ActionResult Login()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(User users)
        {
            if(ModelState.IsValid)
            {
                using (DataContext db = new DataContext())
                {
                    var obj = db.Users.Where(u => u.username.Equals(users.username) && u.Password.Equals(users.Password)).FirstOrDefault();
                    if(obj != null)
                    {
                        Session["UserId"] = obj.userId.ToString();
                        Session["Username"] = obj.username.ToString();
                        return RedirectToAction("LoggedIn");
                    }

                }
            }
            else
            {
                ModelState.AddModelError("", " Some Error Occured");
            }


            return View(users);
        }

        public ActionResult LoggedIn()
        {
            if (Session["UserId"] != null)
            {
                return View();
            }
            else
            {
                return RedirectToAction("Login");
            }
           
        }

        [HttpGet]
        public ActionResult profile(User usr )
        {
            
            User current_user = new User();
            current_user = db.Users.Where(x => x.username == "taha.attique").FirstOrDefault();

            return View(current_user);
        }

    }

}