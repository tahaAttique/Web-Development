﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Data.SqlClient;
using System.Data;

namespace Assignment2
{
    

    public partial class _Default : Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
           
            if (!IsPostBack)
            {
                lbError.Visible = false;
            }
            else
            {
            }
        }

        protected void bsubmit_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=Assignment_2;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open(); 
                string query = "SELECT COUNT(1) FROM Users WHERE Username=@username AND Password=@password";
                SqlCommand sqlCmd = new SqlCommand(query,sqlCon);
                sqlCmd.Parameters.AddWithValue("@username",txtUsername.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@password",txtPassword.Text.Trim());
                int count = Convert.ToInt32(sqlCmd.ExecuteScalar());

                if(count==1)
                {
                    Session["username"] = txtUsername.Text.Trim();
                    Response.Redirect("home.aspx");
                }
                else
                {
                    lbError.Visible = true;
                }

            }
            
        }

        protected void breg_Click(object sender, EventArgs e)
        {
            Response.Redirect("Register.aspx");
        }
    }
}