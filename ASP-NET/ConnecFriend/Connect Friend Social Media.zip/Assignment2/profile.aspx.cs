﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment2
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"] == null)
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                lbActiveSession.Text = "Active Session: " + Session["username"];
            }


            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=Assignment_2;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM allPosts WHERE senderName='Taha Attique'";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                RepeaterPosts.DataSource = ds;
                RepeaterPosts.DataBind();

            }


        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }

        protected void bLogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("Default.aspx");
        }
        protected void search_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=Assignment_2;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "SELECT * FROM Friends WHERE (Username LIKE '%' + @search + '%')";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@search", txtSearch.Text.Trim());
                sqlCmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlCmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "Username");
                GridViewSearch.DataSource = ds;
                GridViewSearch.DataBind();


            }
        }
        string photo_path = null;
        protected void cp1stLBBB_Click(object sender, ImageClickEventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                string extension = System.IO.Path.GetExtension(FileUpload1.FileName);
                lbPhotoUpload.Text = extension;

                if (extension == ".jpg" || extension == ".png" || extension == ".gif")
                {
                    string path = Server.MapPath("\\");
                    lbPhotoUpload.Text = path;

                    FileUpload1.SaveAs(path + FileUpload1.FileName);
                    lbPhotoUpload.Text = "Saved";
                    photo_path = FileUpload1.FileName;

                    ViewState["photoPath"] = FileUpload1.FileName;
                }
                else
                {
                    lbPhotoUpload.Text = "Image file can only be .jpg, .png , and .gif ";
                }
            }
            else
            {
                lbPhotoUpload.Text = "Plz select a file";
            }
        }

        protected void bPost_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=Assignment_2;Integrated Security=True;Pooling=False"))
            {
                if (ViewState["photoPath"] != null)
                {
                    photo_path = (string)ViewState["photoPath"];
                }
                sqlCon.Open();
                string query = "INSERT INTO allPosts VALUES('dp.png','Taha Attique',@status,@sImage,@pTime)";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@status", txtStatus.Text.Trim());

                if (photo_path != null)
                {
                    sqlCmd.Parameters.AddWithValue("@sImage", photo_path.Trim());
                }
                else
                {
                    photo_path = "";
                    sqlCmd.Parameters.AddWithValue("@sImage", photo_path.Trim());
                }


                sqlCmd.Parameters.AddWithValue("@pTime", (string.Format("{0:HH:mm:ss tt}", DateTime.Now)).Trim());
                sqlCmd.ExecuteNonQuery();

                Page.Response.Redirect(Page.Request.Url.ToString(), true);


            }
        }

        Label l1;

        protected void repeatData_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {

                var btn = e.Item.FindControl("bDel") as Button;
                var btnLike = e.Item.FindControl("bLike") as Button;

                if (btn != null)
                {
                    btn.Click += new EventHandler(bDel_Click);
                }
                if (btnLike != null)
                {
                    btnLike.Click += new EventHandler(bLike_Click);
                }



                // int likes1 = Convert.ToInt32(lbLike.Text) + 1;
                //  bLike.Text =  likes1.ToString();


            }
        }



        protected void bLike_Click(object sender, EventArgs e)
        {
            var argument = ((Button)sender).CommandArgument;
        }


        protected void bDel_Click(object sender, EventArgs e) //Bdel
        {
            var argument = ((Button)sender).CommandArgument;

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=Assignment_2;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "DELETE FROM allPosts WHERE (Id=@var1)";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@var1", argument.Trim());
                sqlCmd.ExecuteNonQuery();
                Page.Response.Redirect(Page.Request.Url.ToString(), true);


            }


        }
    }
}
