﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assignment2
{
    public partial class WebForm1 : System.Web.UI.Page 
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lbSuccess.Visible = false;
            blogin.Visible = false;
        }

        protected void breg_Click(object sender, EventArgs e)
        {

            using (SqlConnection sqlCon = new SqlConnection(@"Data Source=DESKTOP-2A4R655\SQLEXPRESS;Initial Catalog=Assignment_2;Integrated Security=True;Pooling=False"))
            {
                sqlCon.Open();
                string query = "INSERT INTO Users VALUES(@full_name,@username,@password)";
                SqlCommand sqlCmd = new SqlCommand(query, sqlCon);
                sqlCmd.Parameters.AddWithValue("@full_name", txtFullname.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@username", txtUsername.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@password", txtPassword.Text.Trim());
                sqlCmd.ExecuteNonQuery();
                lbSuccess.Visible = true;
                blogin.Visible = true;


            }

           

        }

        protected void blogin_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }
    }
}