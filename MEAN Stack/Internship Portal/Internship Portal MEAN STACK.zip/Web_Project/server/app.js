require('./config/config');
require('./models/db');
require('./config/passportConfig');

// the below three are made in sequence 
const express= require('express');
const bodyParser = require('body-parser');
const cors= require('cors'); 
const passport= require('passport');

const rtsIndex = require('./routes/index.router');   // request statement for index router 

var app=express();

//middleware
app.use(bodyParser.json());   // configuring the middleware of the application
app.use(cors());
app.use(passport.initialize());
app.use('/api',rtsIndex);  // confiring the middleware

//error handler    // this is how we can handel error msgs globally
app.use((err,req,res,next)=>{
    if(err.name== 'ValidationError')
    {
        var valErrors=[];
        Object.keys(err.errors).forEach(key => valErrors.push(err.errors[key].message));
        res.status(422).send(valErrors)
    }
}); 

//start server 
app.listen(process.env.PORT, () => console.log(`Server Started at port : ${process.env.PORT}`)); // () shows no parameter 
