const express = require('express');
const router =express.Router(); // the return is saved in router and using this const(router) we will configure routing

const ctrlUser=require('../controllers/user.controller'); //ctrl-> controllers
const ctrlInternshipApplication=require('../controllers/InternshipApplication.controller');

const jwtHelper = require('../config/jwtHelper');

router.post('/register',ctrlUser.register);  // router.post(URI,varControllar.functionName);
router.post('/authenticate', ctrlUser.authenticate);
router.post('/InternshipApplication',ctrlInternshipApplication.application);
router.get('/AllApplication',ctrlInternshipApplication.AllApplication);

module.exports=router; // we export this router to configure routing middleware inside this application and app.js


