//check env.                                         // env tells that it is production or development 
var env = process.env.NODE_ENV || 'development';     // NODE_ENV=production node app.js    // this is command to run. production will
//                                                     become development or in case of no command it will itself become a development ENV
//fetch env. config 
var config= require('./config.json');  //  all data in config, in case of development ...  "PORT": 3000, "MONGODB_URI": "mongodb://localhost:27017/MEANStackDB" ...

var envConfig= config[env];  // sending env for the above mentioned thing

//add env. config values to process.env
Object.keys(envConfig).forEach(key => process.env[key]= envConfig[key]);

//Object.keys(envConfig) returns the config.json data like port and MONGODB_URI 
//in order to retrive the PORT or MONGODB_URI we can use this ' process.env' in other js files