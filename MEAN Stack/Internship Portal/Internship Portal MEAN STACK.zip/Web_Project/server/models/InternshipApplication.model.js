const mongoose = require('mongoose');

var InternshipApplicationSchema = new mongoose.Schema({
    fullName:{
        type: String,
        required: 'Full name can\'t be empty'
    },
    age:{
        type:Number,
        required: 'Age can\'t be empty'
    },
    gender:{
        type: String,
        required: 'gender can\'t be empty'
    },
    DOB:{

        type: String,
        required: 'Date can\'t be empty'
    },
    CNIC:{
        type:Number,
        required: 'CNIC can\'t be empty'
    },
    Picture:
    {
        type:String,
        required: 'Picture required'
    },
    skills:{
        type: String,
    },
    activities:{
        type: String,
    },
    achievements:{
        type: String,
    },
    experience:{
        type: String,
    },
        
});

mongoose.model('InternshipApplication',InternshipApplicationSchema); 