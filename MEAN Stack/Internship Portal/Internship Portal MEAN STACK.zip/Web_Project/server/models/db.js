const mongoose= require('mongoose');

//to connect to mongoDB. Used process.env to retrive MONGODB_URI . (err) is the argument which hv errors if any.
mongoose.connect(process.env.MONGODB_URI, (err)=> {
    if(!err){ console.log('MongoDB connection succeeded');}
    else {console.log('Error in MongoDB connection:' + JSON.stringify(err,undefined,2)); }  //  JSON.stringify..  is used for giving proper
});                                                                                         // spacing in the error msgs.

require('./user.model');
require('./InternshipApplication.model');

