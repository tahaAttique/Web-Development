const mongoose = require('mongoose');
const bcrypt = require('bcrypt');  //     saltSecret:String
const jwt=require('jsonwebtoken'); 

// userSchema -> like table and all
var userSchema = new mongoose.Schema({
    fullName:{
        type: String,
        required: 'Full name can\'t be empty'
    },
    email:{
        type: String,
        required: 'Email name can\'t be empty',
        unique:true
    },
    rollNumber:{
        type: String,
        required: 'Roll Number can\'t be empty'
    },
    password: {
        type:String,
        required: 'Password can\'t be empty',
        minlength : [4,'Password must be atleast 4 character long']
    },
    saltSecret:String
});

//custom validation for email
// userSchema.path('email').validate((val) => {
//     var emailRegex = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
//     return emailRegex.test(val); // Assuming email has a text attribute
//  }, 'Invalid Email.');

// Events
userSchema.pre('save', function (next) {
    bcrypt.genSalt(10, (err, salt) => {
        bcrypt.hash(this.password, salt, (err, hash) => {
            this.password = hash;
            this.saltSecret = salt;
            next();
        });
    });
});

// Methods
userSchema.methods.verifyPassword = function (password) {
   return bcrypt.compareSync(password, this.password);
  
};

userSchema.methods.generateJwt = function () {
    return jwt.sign({ _id: this._id},
        process.env.JWT_SECRET,
    {
        expiresIn: process.env.JWT_EXP
    });
}


mongoose.model('User',userSchema);   // This command registers userSchema inside mongooes. Schema will is stored in the collection named users


// We will hv to add this file in db.js. db.js is already included in the app.js file.