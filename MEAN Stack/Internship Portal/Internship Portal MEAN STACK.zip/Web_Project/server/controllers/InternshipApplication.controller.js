const mongoose =require('mongoose');
const _ = require('lodash');
const InternshipApplication=mongoose.model('InternshipApplication');  

module.exports.application = (req,res,next) => {
    
     var application =new InternshipApplication();
     application.fullName= req.body.fullName;   // here we are retriving the values from the req -> req.body  
     application.age= req.body.age;
     application.gender= req.body.gender;
     application.DOB= req.body.DOB;
     application.CNIC= req.body.CNIC;
     application.Picture= req.body.Picture;
     application.skills= req.body.skills;
     application.activities= req.body.activities;
     application.achievements= req.body.achievements;
     application.experience= req.body.experience;
     application.save((err,doc) => {         // two parameter errors will be passed to err and newly created details will be passed through doc 
        if(!err)                     // "like -> this can't be empty"
             res.send(doc);
         else
         { 
            //console.log(err);
            if(err.code == 11000)
                res.status(422).send(['Duplicate email address found.']);
            else
                return next(err);
         }    
    });
}

module.exports.AllApplication = (req, res, next) => {
    var resultArray=[];
    var cursor=mongoose.Collection('internshipapplications').find();
    cursor.array.forEach(function (doc,err) {
        if(!err)
        {
            resultArray.push(doc);
        }   
    },function(){
        res.render('InternshipApplication.controller',{items: resultArray });
    }
    );
}
