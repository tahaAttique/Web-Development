// User controller is used to define the functions for registration and sign-up


const mongoose =require('mongoose');
const passport=require('passport');
const User=mongoose.model('User');  // importing the schema which we created  with the name of User in user.model.js

// this is register func which has three parameters request,responce and next
module.exports.register = (req,res,next) => {
    
    //console.log('i am in register ');

     var user =new User();
     user.fullName= req.body.fullName;   // here we are retriving the values from the req -> req.body  
     user.email= req.body.email;
     user.rollNumber=req.body.rollNumber;
     user.password=req.body.password;
     user.save((err,doc) => {         // two parameter errors will be passed to err and newly created details will be passed through doc 
        if(!err)                     // "like -> this can't be empty"
             res.send(doc);
         else
         { 
            //console.log(err);
            if(err.code == 11000)
                res.status(422).send(['Duplicate email address found.']);
            else
                return next(err);
         }    
    });
}

module.exports.authenticate = (req, res, next) => {
    // call for passport authentication
    passport.authenticate('local', (err, user, info) => {       
        // error from passport middleware
        if (err) return res.status(400).json(err);
        // registered user
        else if (user) return res.status(200).json({ "token": user.generateJwt() });
        // unknown user or wrong password
        else return res.status(404).json(info);
    })(req, res);
}

