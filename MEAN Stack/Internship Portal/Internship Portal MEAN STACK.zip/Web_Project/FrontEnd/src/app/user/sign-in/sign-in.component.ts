import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from "@angular/router";
import { UserService } from 'src/app/shared/user.service';

@Component({
  selector: 'app-sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css'],
  providers:[UserService]
})
export class SignInComponent implements OnInit {

  serverErrorMessages: string;
  constructor(private userService : UserService ,private router : Router) { }

  model ={
    email:'',
    rollNumber:'',
    password:''
  };

  ngOnInit() {
  }

  onSubmit(form : NgForm){
    this.userService.login(form.value).subscribe(
      res => {
        this.userService.setToken(res['token']);
        if(form.value.email=="web2019@gmail.com")
        {
          this.router.navigateByUrl('/adminHome');
        }
        else
        {
          this.router.navigateByUrl('/InternshipApplication');
        }
        

        

      },
      err => {
        this.serverErrorMessages = err.error.message;
      }
    );
  }
}
