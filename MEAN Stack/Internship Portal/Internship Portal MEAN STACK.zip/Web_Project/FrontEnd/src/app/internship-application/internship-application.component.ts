import { Component, OnInit } from '@angular/core';
import { InternshipApplicationService } from '../shared/internship-application.service';
import { NgForOf } from '@angular/common';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-internship-application',
  templateUrl: './internship-application.component.html',
  styleUrls: ['./internship-application.component.css'],
  providers: [InternshipApplicationService]
})
export class InternshipApplicationComponent implements OnInit {

  showSuccessMessage:boolean;
  serverErrorMessages: string;
  constructor(private IApplicationService: InternshipApplicationService) { }

  ngOnInit() {
  }

  onSubmit(form: NgForm)
  {
    this.IApplicationService.postInternshipApplication(form.value). subscribe(
      res => {
        this.showSuccessMessage=true;
        setTimeout(()=> this.showSuccessMessage=false,4000);
        this.resetForm(form);
      },
      err => {
        if(err.status== 422)
        {
          this.serverErrorMessages = err.error.join('<br>');
        }
        else
        {
          this.serverErrorMessages="Something went wrong.Please contact admin.";
        }
      }
    );
  }

  resetForm(form:NgForm){
    this.IApplicationService.selectedIApplication=
    {
      fullName:'',
      age:null,
      gender: '',
      DOB: '',
      CNIC: '',
      Picture: '',
      skills: '',
      activities: '',
      achievements: '',
      experience: '',
    };
    form.resetForm();
    this.serverErrorMessages='';
  }
}
