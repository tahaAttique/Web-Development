import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { InternshipApplication } from './internship-application.model';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class InternshipApplicationService {

  selectedIApplication: InternshipApplication = {
    fullName: '',
    age:null,
    gender: '',   
    DOB: '', 
    CNIC: '',
    Picture: '',
    skills: '',
    activities: '',
    achievements: '',
    experience: '',
  }
  constructor(private http: HttpClient) { 
 
  }

  postInternshipApplication(internshipApplication:InternshipApplication)
  {
    return this.http.post(environment.apiBaseUrl+'/InternshipApplication',internshipApplication);      //post(URL,user)
  }    
}
