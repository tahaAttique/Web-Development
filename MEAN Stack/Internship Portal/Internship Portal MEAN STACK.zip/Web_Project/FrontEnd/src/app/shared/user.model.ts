export class User {
    fullName:string;
    email:string;
    rollNumber:string;
    password: string;
}
