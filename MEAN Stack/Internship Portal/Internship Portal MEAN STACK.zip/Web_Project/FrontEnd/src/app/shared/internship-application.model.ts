export class InternshipApplication {
    fullName:string;
    age:number;
    gender: string;
    DOB: string;
    CNIC: string;
    Picture: string;
    skills: string;
    activities:string;
    achievements:string;
    experience:string;
}
