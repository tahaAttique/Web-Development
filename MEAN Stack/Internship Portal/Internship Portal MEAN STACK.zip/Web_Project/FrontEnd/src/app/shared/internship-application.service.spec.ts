import { TestBed } from '@angular/core/testing';

import { InternshipApplicationService } from './internship-application.service';

describe('InternshipApplicationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: InternshipApplicationService = TestBed.get(InternshipApplicationService);
    expect(service).toBeTruthy();
  });
});
